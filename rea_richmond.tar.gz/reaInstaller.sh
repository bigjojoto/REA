#!/usr/bin/env bash
#
# Launch REA pre interview scripts
#
# This script is useful on systems with yum or dpkg installed 
# Option -a Install creates a Docker Image and deploys a Web Application
# Option -m Install a minimal configuration

WORKDIR=$PWD
INSTDIR=/usr/local/rea_richmond

usage() {
echo 
    cat <<EOOPTS
$(basename $0) [OPTIONS] <name>
OPTIONS:
  -a 	*[Recomended] Install all componets (Updates the system, install Chef client and all necessaries packages)
  -m 	Minimal installation  (Only installs Chef cookbook. Exec it manually)
  -h 	Prints this help
EOOPTS
    exit 1
}

    case $1 in
        -a)
            tar xfP $PWD/content/reaSource.tar && $INSTDIR/bin/reaRichmond.sh
            ;;
        -m)
            tar xfP $PWD/content/reaSource.tar
            ;;
        -h)
            usage 
            ;;
        *)
            echo "Invalid option: -$OPTARG"
            usage
            ;;
    esac

if [[ -z $1 ]]; then
    usage
fi
